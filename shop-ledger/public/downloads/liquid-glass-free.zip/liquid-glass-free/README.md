# Liquid Glass

**Liquid Glass** is an interactive GLSL distortion shader for modern WebGL and Three.js experiences.

Created by **DevLab by Luka**.

## What's Included

* GLSL vertex shader
* GLSL fragment shader
* Procedural noise and FBM distortion
* Mouse interaction
* Chromatic aberration
* Basic usage documentation

## Files

```text
liquid-glass/
├── shaders/
│   ├── vertex.glsl
│   └── fragment.glsl
│
├── README.md
└── LICENSE.txt
```

## Uniforms

| Uniform                | Description                      |    Default |
| ---------------------- | -------------------------------- | ---------: |
| `uTexture`             | Image texture used by the shader |          — |
| `uTime`                | Animation time                   |      `0.0` |
| `uStrength`            | Distortion intensity             |      `1.0` |
| `uSpeed`               | Animation speed                  |      `0.7` |
| `uNoise`               | Procedural noise intensity       |      `1.0` |
| `uMouseInfluence`      | Mouse interaction strength       |      `1.0` |
| `uChromaticAberration` | RGB color separation             |    `0.012` |
| `uMouse`               | Mouse position                   | `0.5, 0.5` |
| `uResolution`          | Canvas resolution                | `1.0, 1.0` |

## Basic Usage

The shader is designed to be used with WebGL or Three.js.

Create a `ShaderMaterial` and provide the required uniforms:

```js
const material = new THREE.ShaderMaterial({
  uniforms: {
    uTexture: { value: texture },
    uTime: { value: 0 },
    uStrength: { value: 1.0 },
    uSpeed: { value: 0.7 },
    uNoise: { value: 1.0 },
    uMouseInfluence: { value: 1.0 },
    uChromaticAberration: { value: 0.012 },
    uMouse: {
      value: new THREE.Vector2(0.5, 0.5),
    },
    uResolution: {
      value: new THREE.Vector2(1, 1),
    },
  },

  vertexShader,
  fragmentShader,
});
```

Update `uTime` every frame:

```js
material.uniforms.uTime.value = clock.getElapsedTime();
```

## Customization

Experiment with the uniforms to create different visual styles.

For a subtle effect:

```text
strength: 0.5
speed: 0.4
noise: 0.6
mouseInfluence: 0.8
chromaticAberration: 0.006
```

For a stronger effect:

```text
strength: 1.5
speed: 1.0
noise: 1.2
mouseInfluence: 1.5
chromaticAberration: 0.02
```

## Requirements

* WebGL-compatible browser
* Three.js or another WebGL framework
* GLSL shader support

## Usage Rights

This free version may be used in:

* Personal projects
* Portfolio websites
* Client websites
* Commercial websites
* Commercial applications

You may modify the shader code for your own projects.

You may **not**:

* Resell the shader files as a standalone product
* Redistribute the original files as another resource pack
* Upload the shader to another marketplace or asset store
* Claim the original shader as your own work
* Include the original shader as a competing downloadable product

See `LICENSE.txt` for the complete license terms.

## Credits

Liquid Glass was created by **DevLab by Luka**.

Website: DevLab by Luka

---

Made for creative developers.
